#!/bin/bash
#升级gcc至9.x
yum -y install centos-release-scl
yum -y install devtoolset-9-gcc devtoolset-9-gcc-c++ devtoolset-9-binutils

#长期使用gcc9.x，放至/etc/profile
echo "source /opt/rh/devtoolset-9/enable"  >> /etc/profile
 
#临时使用gcc-9
scl enable devtoolset-9 bash

