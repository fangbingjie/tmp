按顺序安装依赖环境gcc和redis

- redis 下载所在目录  /usr/local/src

- redis安装和配置文件所在目录  /usr/local/redis
- 脚本已加入开机自启
- 关闭redis ：pkill redis