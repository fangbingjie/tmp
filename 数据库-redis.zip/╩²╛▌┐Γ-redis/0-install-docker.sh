#!/bin/bash

rpm -qa | grep docker && echo -e "\033[32;32m 已安装docker，退出安装docker步骤 \033[0m \n" && return

yum remove docker \
           docker-client \
           docker-client-latest \
           docker-common \
           docker-latest \
           docker-latest-logrotate \
           docker-logrotate \
           docker-engine -y

yum install -y yum-utils epel-release  device-mapper-persistent-data lvm2
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
yum makecache fast
yum -y install docker-ce docker-ce-cli

systemctl enable docker.service
systemctl start docker.service
systemctl stop docker.service
echo '{"registry-mirrors": ["https://9lxci0ss.mirror.aliyuncs.com"], "log-opts": {"max-size":"500m", "max-file":"3"}}' > /etc/docker/daemon.json

systemctl daemon-reload
systemctl start docker
