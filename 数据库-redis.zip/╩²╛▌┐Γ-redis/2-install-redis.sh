#!/bin/bash

#下载redis
cd /tmp
curl -o redis-6.0.5.tar.gz  http://download.redis.io/releases/redis-6.0.5.tar.gz

#安装gcc编译软件
yum install gcc-c++ tcl -y

#解压
tar -zxvf redis-6.0.5.tar.gz

#把解压的文件移动到/usr/local/src里面
mv  /tmp/redis-6.0.5 /usr/local/src/redis

#打开/usr/local/src/redis进行编译，编译安装目录/usr/local/redis
cd /usr/local/src/redis
mkdir /usr/local/redis/conf -p
make && make install PREFIX=/usr/local/redis

#把配置文件移动到/usr/local/redis/config目录[目录可以自定义]
cp  /usr/local/src/redis/redis.conf /usr/local/redis/conf

#修改redis配置文件
sed -i 's/^daemonize no/daemonize yes/' /usr/local/redis/conf/redis.conf
sed -i 's/^supervised no/supervised auto/' /usr/local/redis/conf/redis.conf

#软链接redis启动命令
ln -s /usr/local/redis/bin/* /usr/bin

#将redis加入systemd服务
cat > /usr/lib/systemd/system/redis.service <<EOF
[Unit]
Description=redis
After=network.target

[Service]
Type=forking
PIDFile=/var/run/redis_6379.pid
ExecStart=/usr/local/redis/bin/redis-server /usr/local/redis/conf/redis.conf
ExecReload=/bin/kill -s HUP $MAINPID
ExecStop=/bin/kill -s QUIT $MAINPID
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

#启动redis并加入开机启动
systemctl daemon-reload
systemctl start redis
systemctl enable redis

